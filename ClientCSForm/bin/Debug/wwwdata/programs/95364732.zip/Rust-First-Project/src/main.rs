use std::{fs::File, io::Write};
use hex_literal::hex;
use sha2::{Sha256, Digest};
use sha256::digest;

fn main() -> std::io::Result<()> {
    let mut file = File::create("out.txt")?;
    let mut n = 0;

    loop
    {
        n += 1;

        let x: i32 = n;
        let s: String = x.to_string();
        let mut owned_string: String = "".to_owned();
        owned_string.push_str(&s);
        
        //let digest = sha256_digest(&owned_string)?;

        let input = String::from(owned_string);

        let mut hasher = Sha256::new();
        hasher.update(input);
        let hash_result = hasher.finalize();
        let string = format!("{:x}", hash_result);
        
        owned_string = string;
        owned_string.push_str("\n");

        print!("{}", owned_string);
        file.write(owned_string.as_bytes())?;

        if owned_string.starts_with("000"){
            break;
        }
    }
    Ok(())
}